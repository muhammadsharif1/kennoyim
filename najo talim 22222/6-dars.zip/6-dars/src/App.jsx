import './App.css';
import Header from './Header/header'
import Main from './Main/Main'
import Footer from './Footer/Footer';
import {Context as ThemeContext} from './Context/Theme'
import React from 'react';

function App() {
  const { theme } = React.useContext(ThemeContext)
  return (
    <div className={`App ${theme === 'light' ? 'light' : 'dark'}`}>
      <Header></Header>
      <Main></Main>
      <Footer></Footer>
    </div>
  );
}

export default App;