import React from "react";
import './footer.css';
import search from '../Assets/Svg/search.svg'
import dock from '../Assets/Images/dock.png'
import mushtariy from '../Assets/Images/Mushtariy.png'
import shuhratbek from '../Assets/Images/Shuhratbek.png'
import { Context } from '../Context/Localization';
import langData from '../Localization/Data'

function Footer() {
    const { state, setState } = React.useContext(Context)
    return(
        <>
            <div className="footer-wrapper">
                <div className="searched">
                    <img src={search} alt="search" width={24} height={24} className="icon-search"/>
                    <input type="text" placeholder={`${langData[state].main.placheholders.placheholder2}`} className="search-input"/>
                </div>
                <div className="trends">
                    <h1 className="trends-header">{langData[state].footer.trends}</h1>
                    <ul className="trends-list">
                        <li className="trend-item">
                            <div className="trend-item-textes">
                                <p className="trends-item-text">
                                    Trending in Germany
                                </p>
                                <h2 className="trends-item-header">
                                    Revolution
                                </h2>
                                <p className="trends-item-popular">
                                    {`50.k ${langData[state].footer.tweets}`}
                                </p>
                            </div>
                            <img src={dock} alt="3dock" width={17} height={4}/>
                        </li>
                        <li className="trend-item">
                            <div className="trend-item-textes">
                                <p className="trends-item-text">
                                    Trending in Germany
                                </p>
                                <h2 className="trends-item-header">
                                    Revolution
                                </h2>
                                <p className="trends-item-popular">
                                {`50.k ${langData[state].footer.tweets}`}
                                </p>
                            </div>
                            <img src={dock} alt="3dock" width={17} height={4}/>
                        </li>
                        <li className="trend-item">
                            <div className="trend-item-textes">
                                <p className="trends-item-text">
                                    Trending in Germany
                                </p>
                                <h2 className="trends-item-header">
                                    Revolution
                                </h2>
                                <p className="trends-item-popular">
                                {`50.k ${langData[state].footer.tweets}`}
                                </p>
                            </div>
                            <img src={dock} alt="3dock" width={17} height={4}/>
                        </li>
                    </ul>
                    <a href="#" className="show-more">{langData[state].footer.more}</a>
                    </div>
                    <div className="follow">
                        <h2 className="follow-header">
                            {langData[state].footer.might}
                        </h2>
                        <ul className="follow-list">
                            <li className="follow-item">
                                <img src={mushtariy} alt="Mushtariy opa" width={60} height={60} className="follow-img"/>
                                <div className="follow-item-text">
                                    <h3 className="follow-item-text-header">
                                        Mushtariy
                                    </h3>
                                    <p className="follow-item-text-ucer">
                                        @Mushtar565266
                                    </p>
                                </div>
                                <button className="follow-ucer">Follow</button>
                            </li>
                            <li className="follow-item">
                                <img src={shuhratbek} alt="Shuhrat aka" width={60} height={60}/>
                                <div className="follow-item-text">
                                    <h3 className="follow-item-text-header">
                                        Shuhratbek
                                    </h3>
                                    <p className="follow-item-text-ucer">
                                        @mrshukhrat
                                    </p>
                                </div>
                                <button className="follow-ucer">Follow</button>
                            </li>
                        </ul>
                        <a href="#" className="show-more">{langData[state].footer.more}</a>
                    </div>
                    <ul className="link">
                        <li className="links-item">
                            <a href="#" className="links-item-link">{langData[state].footer.terms}</a>
                        </li>
                        <li className="links-item">
                            <a href="#" className="links-item-link">{langData[state].footer.privacy}</a>
                        </li>
                        <li className="links-item">
                            <a href="#" className="links-item-link">{langData[state].footer.cookie}</a>
                        </li>
                        <li className="links-item">
                            <a href="#" className="links-item-link">{langData[state].footer.imprint}</a>
                        </li>
                        <li className="links-item">
                            <a href="#" className="links-item-link">{langData[state].footer.ads}</a>
                        </li>
                        <li className="links-item">
                            <a href="#" className="links-item-link">{langData[state].footer.more2}</a>
                        </li>
                        <li className="links-item">
                            <a href="#" className="links-item-link">© 2021 Twitter, Inc.</a>
                        </li>
                    </ul>
                </div>
        </>
    )
}

export default Footer
