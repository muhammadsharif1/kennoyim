import React from "react";
import './header.css'
import logo from '../Assets/Images/logo.png'
import Home from "../Assets/Svg/home";
import Bookmark from '../Assets/Svg/bookmarks'
import Explore from '../Assets/Svg/explore'
import Notifications from '../Assets/Svg/notification'
import Messages from '../Assets/Svg/messages'
import Lists from '../Assets/Svg/lists'
import Profile from '../Assets/Svg/profile'
import More from '../Assets/Svg/more'
import langData from '../Localization/Data'
import themee from '../Localization/Themeee'
import bobur from '../Assets/Images/Bobur.png'
import dock from '../Assets/Images/dock.png'
import { Context } from '../Context/Localization'
import { Context as ThemeContext } from '../Context/Theme'

function Header() {
    const { state, setState } = React.useContext(Context)
    const { theme, setTheme } = React.useContext(ThemeContext)
    return <div className={`wrapper ${theme === 'light' ? 'border' : 'border-white'}`}>
            <img src={logo} alt="logo" className="logo"/>
            <nav className="nav">
                <ul className="nav-list">
                    <li className="nav-item">
                        <Home color={themee[theme].darkColor}/>
                        <a href="#" className={`nav-link ${theme === 'light' ? 'light' : 'dark'}`}>{langData[state].header.nav.home}</a>
                    </li>
                    <li className="nav-item">
                        <Explore color={themee[theme].darkColor}/>
                        <a href="#" className={`nav-link ${theme === 'light' ? 'light' : 'dark'}`}>{langData[state].header.nav.explore}</a>
                    </li>
                    <li className="nav-item">
                        <Notifications color={themee[theme].darkColor}/>
                        <a href="#" className={`nav-link ${theme === 'light' ? 'light' : 'dark'}`}>{langData[state].header.nav.notifications}</a>
                    </li>
                    <li className="nav-item">
                        <Messages color={themee[theme].darkColor}/>
                        <a href="#" className={`nav-link ${theme === 'light' ? 'light' : 'dark'}`}>{langData[state].header.nav.messages}</a>
                    </li>
                    <li className="nav-item">
                        <Bookmark color={themee[theme].darkColor}/>
                        <a href="#" className={`nav-link ${theme === 'light' ? 'light' : 'dark'}`}>{langData[state].header.nav.bookmarks}</a>
                    </li>
                    <li className="nav-item">
                        <Lists color={themee[theme].darkColor}/>
                        <a href="#" className={`nav-link ${theme === 'light' ? 'light' : 'dark'}`}>{langData[state].header.nav.lists}</a>
                    </li>
                    <li className="nav-item">
                        <Profile color={themee[theme].darkColor}/>
                        <a href="#" className={`nav-link ${theme === 'light' ? 'light' : 'dark'}`}>{langData[state].header.nav.profile}</a>
                    </li>
                    <li className="nav-item">
                        <More color={themee[theme].darkColor}/>
                        <a href="#" className={`nav-link ${theme === 'light' ? 'light' : 'dark'}`}>{langData[state].header.nav.more}</a>
                    </li>
                </ul>
                <button className="nav-button">{langData[state].header.nav.tweet}</button>
            </nav>

            <div className="ucer">
                <img src={bobur} alt="Brat" width={50} height={50}/>
                <div className="ucer-wrapper">
                    <h4 className="ucer-header">Bobur</h4>
                    <p className="ucer-text">@bobur_mavlonov</p>
                </div>
                <img src={dock} alt="dock" width={17} height={4} className="dock"/>
            </div>
        </div>
}

export default Header