const data = {
	uz: {
		header: {
			nav: {
				home: 'Bosh sahifa',
				explore: 'Kashf qilish',
                notifications: "Bildirshnomalar",
                messages: "Habarlar",
                bookmarks: "Saralanganlar",
                lists: "Ro'yxatlar",
                profile: "Shaxsiy profil",
                more: "Qo'shimcha ma'lumotlar",
                tweet: "Tweet"
			},
		},

		main: {
			placheholders: { 
                placheholder1: "Nima gaplar",
                placheholder2: "Tweet izlash"
            },
            hour: "s"    
            },
		

		footer: {
			trends: "Siz uchun trendlar",
            tweets: "Yangiliklar",
            might: "Siga yoqishi mumkin bo'lganlar",
            follow: "Obuna bo'lish",
            more: "Yana ko'rsatish",
            terms: "Xizmat shartlari",
            privacy: "Maxfiylik siyosati",
            cookie: "Cookie siyosati",
            imprint: "Iz",
            ads: "Reklama ma'lumotlari",
            more2: "Yana",
            
		},
	},
	en: {
		header: {
			nav: {
				home: 'Home',
				explore: 'Explore',
                notifications: "Notifications",
                messages: "Messages",
                bookmarks: "Bookmarks",
                lists: "Lists",
                profile: "Profile",
                more: "More",
                tweet: "Tweet"
			},
		},

		main: {
			placheholders: { 
                placheholder1: "What’s happening",
                placheholder2: "Search Twitter"
            },
            hour: "h"    
            },
		

		footer: {
			trends: "Trends for you",
            tweets: "Tweets",
            might: "You might like",
            follow: "Follow",
            more: "Show more",
            terms: "Terms of Service",
            privacy: "Privacy Policy",
            cookie: "Cookie Policy",
            imprint: "Imprint",
            ads: "Ads Info",
            more2: "More",
            
		},
	}
}

export default data 