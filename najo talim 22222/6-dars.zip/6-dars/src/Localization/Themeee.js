var theme = {
    light:{
        white: "white",
        darkColor: "black"
    },
    dark:{
        white: "black",
        darkColor: "white"
    }
}

export default theme