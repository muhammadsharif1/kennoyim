import React from "react";
import './main.css';
import bobur from '../Assets/Images/Bobur.png';
import image from '../Assets/Svg/image.svg';
import gif from '../Assets/Svg/gif.svg';
import stats from '../Assets/Svg/stats.svg';
import smile from '../Assets/Svg/smile.svg';
import frame from '../Assets/Svg/Frame.svg';
import designes from '../Assets/Images/designes.png';
import clout from '../Assets/Images/clout.png';
import creative from '../Assets/Images/creative.png';
import comment from '../Assets/Svg/tweetInfo/comment.svg';
import retweet from '../Assets/Svg/tweetInfo/retweet.svg';
import Like from '../Assets/Svg/tweetInfo/like';
import share from '../Assets/Svg/tweetInfo/share.svg';
import statis from '../Assets/Svg/tweetInfo/statistics.svg';
import dock from '../Assets/Images/dock.png';
import kabab from '../Assets/Images/shashlik.png';
import { Context } from '../Context/Localization';
import { Context as ThemeContext } from '../Context/Theme';
import langData from '../Localization/Data';



function Main() {
    const { state, setState } = React.useContext(Context)
    const { theme, setTheme } = React.useContext(ThemeContext)
    const [count1, setCount1] = React.useState(false)
    const [count2, setCount2] = React.useState(false)
    const [count3, setCount3] = React.useState(false)

    return(
        <div className="wrapper-main">
            <div className="main-top">
                <h1 className="main-top_header">{langData[state].header.nav.home}</h1>
                <select className={`main-top-select ${theme === 'light' ? 'bnma' : 'backround-black'}`} onChange={(evt)=>{
                    setTheme(evt.target.value);
                }}>
                    <option className={theme === 'light' ? 'option' : 'backround-black'} value="light">Light</option>
                    <option className={theme === 'light' ? 'option' : 'backround-black'} value="dark">Dark</option>
                </select>
                <select className={`main-top-select ${theme === 'light' ? 'bnma' : 'backround-black'}`} onChange={(evt)=>{
                    setState(evt.target.value);
                }}>
                    <option className={theme === 'light' ? 'option' : 'backround-black'} value="en">ENG</option>
                    <option className={theme === 'light' ? 'option' : 'backround-black'} value="uz">UZ</option>
                </select>
            </div>
            <div className={`comment ${theme === 'light' ? 'prosta' : 'border-bottom'}`}>
                <div className="comment-text">
                    <img src={bobur} alt="Brat" width={60} height={60}/>
                    <input type="text" placeholder={langData[state].main.placheholders.placheholder1} className={`comment-input ${theme === 'light' ? 'color-black' : 'color-white'}`}/>
                </div>
                <div className="icons">
                    <img className="icon" src={image} alt="image" width={20} height={20}/>
                    <img className="icon" src={gif} alt="image" width={20} height={20}/>
                    <img className="icon" src={stats} alt="image" width={20} height={20}/>
                    <img className="icon" src={smile} alt="image" width={20} height={20}/>
                    <img className="icon" src={frame} alt="image" width={20} height={20}/>
                </div>
                <button disabled className="tweet-button">Tweet</button>
            </div>
            <div className="tweets">
                <div className={`tweet ${theme === 'light' ? 'prosta' : 'border-bottom'}`}>
                    <img src={designes} alt="designes" width={60} height={60}/>
                    <div className="tweet-text">
                        <div className="tweet-header">
                            <h2 className="tweet-heading">Designsta</h2>
                            <p className="tweet-ucer">
                                @inner · 25m
                            </p>
                        </div>
                        <p className="tweet-info">
                            Twitterdagi ayol-erkak qarama-qarshiliginglardan o'zinglar zerikmadinglarmi?
                        </p>
                        <div className="tweet-icons">
                            <div className="tweet-icon">
                                <img className="tweet-icon-img" src={comment} alt="comment" width={24} height={24}/>
                                <p>10</p>
                            </div>
                            <div className="tweet-icon">
                                <img className="tweet-icon-img" src={retweet} alt="retweet" width={24} height={24}/>
                                <p>1</p>
                            </div>
                            <div className="tweet-icon" onClick={()=> setCount1(count1 == true ?count1 -1 : count1 + 1)}>
                                <Like color={count1 ? "red": "#536471"}></Like>
                                <p>{8 + count1}</p>
                            </div>
                            <div className="tweet-icon">
                                <img className="tweet-icon-img" src={share} alt="share" width={24} height={24}/>
                            </div>
                            <div className="tweet-icon">
                                <img className="tweet-icon-img" src={statis} alt="statis" width={24} height={24}/>
                            </div>
                        </div>
                    </div> 
                    <img className="dock3" src={dock} alt="3dock" width={17} height={4}/>
                </div>
                <div className={`tweet ${theme === 'light' ? 'prosta' : 'border-bottom'}`}>
                    <img src={clout} alt="clout" width={60} height={60}/>
                    <div className="tweet-text">
                        <div className="tweet-header">
                            <h2 className="tweet-heading">cloutexhibition</h2>
                            <p className="tweet-ucer">
                                @RajLahoti · 22m
                            </p>
                        </div>
                        <p className="tweet-info">
                            YPIP dasturining bu yilgi sezoni ham o’z nihoyasiga yetmoqda. Mentorlik davomida talaba va yangi bitiruvchilarni o’sayotganini ko’rib hursand bo’ladi odam.</p>
                        <div className="tweet-icons">
                            <div className="tweet-icon">
                                <img className="tweet-icon-img" src={comment} alt="comment" width={24} height={24}/>
                                <p></p>
                            </div>
                            <div className="tweet-icon">
                                <img className="tweet-icon-img" src={retweet} alt="retweet" width={24} height={24}/>
                                <p>5</p>
                            </div>
                            <div className="tweet-icon" onClick={()=> setCount2(count2 == true ? count2 -1 : count2 + 1)}>
                                <Like className="tweet-icon-img" color={count2 ? "red": "#536471"} />
                                <p>{8 + count2}</p>
                            </div>
                            <div className="tweet-icon">
                                <img className="tweet-icon-img" src={share} alt="share" width={24} height={24}/>
                            </div>
                            <div className="tweet-icon">
                                <img className="tweet-icon-img" src={statis} alt="statis" width={24} height={24}/>
                            </div>
                        </div>
                    </div> 
                    <img className="dock3" src={dock} alt="3dock" width={17} height={4}/>
                </div>
            </div>
            <div className="tweet">
                <img src={creative} alt="creative" width={60} height={60}/>
                <div className="tweet-text">
                    <div className="tweet-header">
                        <h2 className="tweet-heading">CreativePhoto</h2>
                        <p className="tweet-ucer">
                           {`@cloutexhibition · ${langData[state].main.hour}`}
                        </p>
                    </div>
                    <p className="tweet-info">
                        Обетда..... 
                    </p>
                    <p className="tweet-info">
                        Кечиринглар
                    </p>
                    <img src={kabab} alt="shashlik" className="kabab"/>
                    <div className="tweet-icons">
                        <div className="tweet-icon">
                            <img className="tweet-icon-img" src={comment} alt="comment" width={24} height={24}/>
                            <p>10</p>
                        </div>
                        <div className="tweet-icon">
                            <img className="tweet-icon-img" src={retweet} alt="retweet" width={24} height={24}/>
                            <p>1</p>
                        </div>
                        <div className="tweet-icon" onClick={()=> setCount3(count3 == true ?count3 -1 : count3 + 1)}>
                        <Like color={count3 ? "red": "#536471"}></Like>
                                <p>{8 + count3}</p>
                        </div>
                        <div className="tweet-icon">
                            <img className="tweet-icon-img" src={share} alt="share" width={24} height={24}/>
                        </div>
                        <div className="tweet-icon">
                            <img className="tweet-icon-img" src={statis} alt="statis" width={24} height={24}/>
                        </div>
                    </div>
                </div> 
                <img className="dock3" src={dock} alt="3dock" width={17} height={4}/>
            </div>
        </div>
    )
}
export default Main