import React from 'react';
import ReactDOM from 'react-dom';
import './index.css';
import App from './App';
import {Provider} from '../src/Context/Localization'
import {Provider as ThemeProvider} from '../src/Context/Theme'


ReactDOM.render(
  <React.StrictMode>
    <ThemeProvider>
      <Provider>
        <App></App>
      </Provider>
    </ThemeProvider>
  </React.StrictMode>,
  document.getElementById('root')
  );
  